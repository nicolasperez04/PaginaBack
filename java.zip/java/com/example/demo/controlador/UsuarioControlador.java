package com.example.demo.controlador;

import com.example.demo.modelo.Usuario;
import com.example.demo.repositorio.UsuarioRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@CrossOrigin(origins= "http://localhost:8080")
@RestController
@RequestMapping("/api/usuarios")

public class UsuarioControlador {

    @Autowired
    private UsuarioRepositorio usuarioRepository;  //inyecta la dependencia en el controlador

    @PostMapping("/register")
    public String registrarUsuario(@RequestBody Usuario usuario) {
        usuarioRepository.save(usuario);
        return "Registro exitoso";
    }

    // Método para manejar la solicitud OPTIONS
    @RequestMapping(value = "/register", method = RequestMethod.OPTIONS)
    public ResponseEntity<?> handleOptions() {
        return ResponseEntity.ok().build();
    }
}
