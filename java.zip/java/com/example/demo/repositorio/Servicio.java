package com.example.demo.repositorio;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.modelo.Usuario;

@Service
public class Servicio {
    @Autowired
    private UsuarioRepositorio usuarioRepositorio;

    public void registrarUsuario(Usuario usuario) {
        // Lógica para guardar el usuario en la base de datos
        usuarioRepositorio.save(usuario);  //toma el objeto usuario para guardarlo en la bd
    }
}
