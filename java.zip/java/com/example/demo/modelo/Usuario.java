package com.example.demo.modelo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity  //mapeada a una bd
public class Usuario {

	@Id     //llave primaria
    @GeneratedValue(strategy = GenerationType.IDENTITY)    //los valores para la clave primaria se generarán automáticamente por la base de datos utilizando una estrategia de identidad
    private Long id;
    private String Nombres;
    private String Apellidos;
    private String Correo;
    private String Contraseña;


}
